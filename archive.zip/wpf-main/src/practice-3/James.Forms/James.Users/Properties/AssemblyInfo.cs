using System.Runtime.InteropServices;

[assembly: System.Windows.ThemeInfo(System.Windows.ResourceDictionaryLocation.None, System.Windows.ResourceDictionaryLocation.SourceAssembly)]

// 이와 같은 SDK 스타일 프로젝트에서는 이 파일에 지금까지 정의된 여러 어셈블리 특성이 이제 빌드 중에 자동으로 추가되고 프로젝트 속성에 정의된
// 값으로 채워집니다. 포함된 특성에 대한 자세한 내용과 이 프로세스를 사용자 지정하는 방법에 대해서는 https://aka.ms/assembly-info-properties를
// 참조하세요.


// ComVisible을 false로 설정하면 이 어셈블리의 형식이 COM 구성 요소에 표시되지 않습니다.  COM에서 이 어셈블리의 형식에 액세스하려면
// 해당 형식에 대해 ComVisible 특성을 true로 설정하세요.

[assembly: ComVisible(false)]

// 이 프로젝트가 COM에 노출되는 경우 다음 GUID는 typelib의 ID를 나타냅니다.

[assembly: Guid("7f1eafa3-2ec5-4a58-b916-923c83ccfca7")]
