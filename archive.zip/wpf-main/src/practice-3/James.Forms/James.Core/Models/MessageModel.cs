﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace James.Core.Models
{
    public class MessageModel
    {
        public string Name { get; set; }
    }
}
