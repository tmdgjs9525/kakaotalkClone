﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace James.Core
{
    public class ContentName
    {
        public static string MainContent = "MainContent";
        public static string UserContent = "UserContent";
    }
}
